const SOURCE_NAME = "红果全集版";
const siteBaseUrl = "https://hongguoduanju.com";
const suggestionUrl = siteBaseUrl + "/incent_resource/suggestion";
const suggestionAppId = "8662";
const cacheTTL = 6 * 60 * 60 * 1000;
const countTTL = 24 * 60 * 60 * 1000;
const playlistLimit = 6 * 1024 * 1024;
const maxSegmentScan = 60000;

const genres = [
  { key: "real-drama", name: "真人剧" },
  { key: "comic-drama", name: "漫剧" },
  { key: "ai-drama", name: "AI剧" },
];

// 片源站（macCMS 采集接口），按画质与命中率排序
const libraries = [
  { id: "modu", name: "魔都影视", base: "https://caiji.moduapi.cc/api.php/provide/vod/" },
  { id: "wujin", name: "无尽影视", base: "https://api.wujinapi.com/api.php/provide/vod/" },
  { id: "zy360", name: "360影视", base: "https://360zy.com/api.php/provide/vod/" },
  { id: "bdzy", name: "百度影视", base: "https://api.apibdzy.com/api.php/provide/vod/" },
  { id: "guangsu", name: "光速影视", base: "https://api.guangsuapi.com/api.php/provide/vod/" },
];

function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isEmptyRecord(value) {
  return !isRecord(value) || Object.keys(value).length === 0;
}

function stringOf(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

function firstNonEmpty(...values) {
  for (const value of values) {
    const text = stringOf(value);
    if (text !== "") {
      return text;
    }
  }
  return "";
}

function intOf(value, fallback) {
  const parsed = parseInt(stringOf(value), 10);
  return isNaN(parsed) ? fallback : parsed;
}

function nested(value, ...keys) {
  let current = value;
  for (const key of keys) {
    if (!isRecord(current)) {
      return undefined;
    }
    current = current[key];
  }
  return current;
}

function anyList(value) {
  return Array.isArray(value) ? value : [];
}

function parseJson(text) {
  const trimmed = (text || "").trim();
  if (trimmed === "") {
    throw new Error("站点返回了空响应");
  }
  try {
    return JSON.parse(host.preserveIntegers(trimmed));
  } catch (error) {
    throw new Error("站点返回的内容不是有效 JSON");
  }
}

function leadingJson(text, start) {
  const end = text.indexOf("</script>", start);
  if (end > start) {
    try {
      const value = parseJson(text.slice(start, end).replace(/[\s;]+$/, ""));
      return isRecord(value) ? value : null;
    } catch (error) {}
  }
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < text.length; index++) {
    const code = text.charCodeAt(index);
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (code === 92) {
        escaped = true;
      } else if (code === 34) {
        inString = false;
      }
      continue;
    }
    if (code === 34) {
      inString = true;
    } else if (code === 123 || code === 91) {
      depth++;
    } else if (code === 125 || code === 93) {
      depth--;
      if (depth === 0) {
        try {
          const value = parseJson(text.slice(start, index + 1));
          return isRecord(value) ? value : null;
        } catch (error) {
          return null;
        }
      }
    } else if (depth === 0 && code > 32) {
      return null;
    }
  }
  return null;
}

function parseRouterData(raw) {
  const match = /(?:window\.)?_ROUTER_DATA\s*=\s*/.exec(raw);
  return match ? leadingJson(raw, match.index + match[0].length) : null;
}

function routerLoaderMap(data, ...names) {
  const loader = nested(data, "loaderData");
  if (!isRecord(loader)) {
    return null;
  }
  for (const name of names) {
    if (!isEmptyRecord(loader[name])) {
      return loader[name];
    }
  }
  for (const key of Object.keys(loader)) {
    for (const name of names) {
      const prefix = name.replace(/\$$/, "");
      if (prefix !== "" && key.indexOf(prefix) === 0 && !isEmptyRecord(loader[key])) {
        return loader[key];
      }
    }
  }
  return null;
}

function fetchSiteText(address) {
  return host.fetchText({ url: address, referer: siteBaseUrl + "/" }).body;
}

function webPage(path) {
  const data = parseRouterData(fetchSiteText(siteBaseUrl + path));
  if (!data) {
    throw new Error("红果网页结构无法解析");
  }
  return data;
}

function coverOf(row) {
  const raw = firstNonEmpty(row.series_cover, row.cover, row.cover_url, row.pic);
  if (raw === "") {
    return "";
  }
  if (raw.indexOf("//") === 0) {
    return "https:" + raw;
  }
  if (raw.indexOf("http") === 0) {
    return raw;
  }
  return raw.indexOf("/") === 0 ? siteBaseUrl + raw : raw;
}

function tagsOf(row) {
  const tags = [];
  const push = (name) => {
    const text = stringOf(name);
    if (text !== "" && tags.indexOf(text) < 0) {
      tags.push(text);
    }
  };
  for (const item of anyList(row.tags)) {
    push(isRecord(item) ? firstNonEmpty(item.name, item.tag_name, item.title) : item);
  }
  for (const item of anyList(row.category_list)) {
    push(isRecord(item) ? firstNonEmpty(item.name, item.category_name) : item);
  }
  return tags;
}

function dramaFromRow(value) {
  if (!isRecord(value)) {
    return null;
  }
  const row = isEmptyRecord(value.video_data) ? value : value.video_data;
  const sourceId = firstNonEmpty(
    row.series_id_str,
    row.series_id,
    value.series_id_str,
    value.series_id,
    value.keyword,
  );
  if (!/^[0-9]{1,32}$/.test(sourceId)) {
    return null;
  }
  const title = firstNonEmpty(row.series_title, row.series_name, row.title, value.name, sourceId);
  const intro = firstNonEmpty(row.series_intro, row.video_desc, row.desc, value.series_intro);
  const count = intOf(firstNonEmpty(row.episode_cnt, value.episode_cnt), 0);
  let remark = firstNonEmpty(row.episode_right_text, value.episode_right_text);
  if (remark === "" && count > 0) {
    remark = "共" + count + "集";
  }
  const status = intOf(row.series_status, -1);
  const tags = tagsOf(row);
  const hot = nested(row, "hot_score_data");
  return {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId: sourceId,
    title: title,
    name: title,
    desc: intro,
    intro: intro,
    cover: coverOf(row),
    coverUrl: coverOf(row),
    categoryName: tags.length ? tags[0] : "红果",
    channelName: "红果",
    remark: remark,
    totalEpisode: count > 0 ? count : undefined,
    episodeCount: count > 0 ? count : undefined,
    tags: tags,
    releaseStatus: status === 1 ? "finished" : status === 0 ? "ongoing" : undefined,
    heat: firstNonEmpty(nested(hot, "text"), row.hot_score_text),
  };
}

function rememberCount(sourceId, count) {
  if (count > 0) {
    host.cacheSet("cnt-" + sourceId, String(count), countTTL);
  }
}

function cachedCount(sourceId) {
  const raw = host.cacheGet("cnt-" + sourceId);
  const parsed = intOf(raw, 0);
  if (parsed > 0) {
    return parsed;
  }
  try {
    const stored = intOf(host.loadState("count-" + sourceId), 0);
    if (stored > 0) {
      return stored;
    }
  } catch (error) {}
  return 0;
}

function episodeCount(sourceId) {
  const cached = cachedCount(sourceId);
  if (cached > 0) {
    return cached;
  }
  const data = webPage("/detail?series_id=" + encodeURIComponent(sourceId));
  const page = routerLoaderMap(data, "detail_page", "detail_");
  const detail = nested(page, "seriesDetail");
  const list = anyList(detail && detail.vid_list);
  const count = list.length || intOf(detail && detail.episode_cnt, 0);
  if (count > 0) {
    rememberCount(sourceId, count);
    try {
      host.saveState("count-" + sourceId, String(count));
    } catch (error) {}
  }
  return count;
}

function normalizeTitle(text) {
  return stringOf(text)
    .replace(/[\s\u3000]/g, "")
    .replace(/[《》「」『』【】\[\]（）()·,，.。:：;；!！?？'"“”‘’\-_/\\|~`@#$%^&*+=]/g, "")
    .replace(/第[0-9零〇一二两兩三四五六七八九十百]+[季部]$/u, "")
    .toLowerCase();
}

function similarity(name, wanted) {
  if (name === "" || wanted === "") {
    return 0;
  }
  if (name === wanted) {
    return 100;
  }
  const shorter = name.length <= wanted.length ? name : wanted;
  const longer = name.length <= wanted.length ? wanted : name;
  const ratio = shorter.length / longer.length;
  const prefix = longer.indexOf(shorter) === 0;
  const rest = prefix ? longer.slice(shorter.length) : "";
  // 前缀命中且剩余部分只是季/部/数字等修饰 → 视为同一部
  if (prefix && /^[0-9零〇一二两兩三四五六七八九十百千万第季部篇集之·]+$/u.test(rest)) {
    return 80;
  }
  // 长度差距过大说明不是同一部（避免「嫌疑人的秘密」误配「嫌疑人的秘密2藏金生死线」）
  if (ratio < 0.75) {
    return 0;
  }
  if (prefix) {
    return 60;
  }
  if (longer.indexOf(shorter) >= 0) {
    return 30;
  }
  return 0;
}

function librarySearch(library, title) {
  const address = library.base + "?ac=detail&wd=" + encodeURIComponent(title);
  const body = host.fetchText({ url: address, referer: library.base }).body;
  const data = parseJson(body);
  return anyList(data.list);
}

function splitPlayGroups(item) {
  const from = stringOf(item.vod_play_from).split("$$$");
  const urls = stringOf(item.vod_play_url).split("$$$");
  const groups = [];
  for (let index = 0; index < urls.length; index++) {
    const raw = stringOf(urls[index]);
    if (raw === "") {
      continue;
    }
    const entries = [];
    for (const part of raw.split("#")) {
      const text = part.trim();
      if (text === "") {
        continue;
      }
      const cut = text.indexOf("$");
      const label = cut >= 0 ? text.slice(0, cut) : "";
      const address = (cut >= 0 ? text.slice(cut + 1) : text).trim();
      if (address === "") {
        continue;
      }
      entries.push({ label: label, address: address });
    }
    if (!entries.length) {
      continue;
    }
    const playable = entries.some((entry) => entry.address.indexOf(".m3u8") >= 0);
    groups.push({ from: stringOf(from[index]), entries: entries, playable: playable });
  }
  return groups;
}

function pickGroup(item) {
  const groups = splitPlayGroups(item).filter((group) => group.playable);
  if (!groups.length) {
    return null;
  }
  // 优先取「全部分集都是 m3u8 直链」的那组
  let best = null;
  let bestScore = -1;
  for (const group of groups) {
    const direct = group.entries.filter((entry) => entry.address.indexOf(".m3u8") >= 0).length;
    const score = direct * 1000 + group.entries.length;
    if (score > bestScore) {
      best = group;
      bestScore = score;
    }
  }
  return best;
}

function searchQueries(title) {
  const queries = [];
  const push = (value) => {
    const text = stringOf(value);
    if (text !== "" && queries.indexOf(text) < 0) {
      queries.push(text);
    }
  };
  push(title);
  // 去掉季/部后缀
  push(title.replace(/第[0-9零〇一二两兩三四五六七八九十百]+[季部]$/u, ""));
  // 长标题按前缀逐级缩短，供片源站用短词命中
  const cleaned = stringOf(title).replace(/[\s\u3000]/g, "");
  for (let length = Math.min(cleaned.length - 1, 12); length >= 4; length -= 1) {
    push(cleaned.slice(0, length));
  }
  return queries;
}

function remarkCount(item) {
  const remark = stringOf(item.vod_remarks);
  const match = /([0-9]{1,4})\s*集/.exec(remark);
  if (!match) {
    return 0;
  }
  return intOf(match[1], 0);
}

function matchLibrary(title) {
  const wanted = normalizeTitle(title);
  if (wanted === "") {
    return null;
  }
  const queries = searchQueries(title);
  for (const library of libraries) {
    const seen = {};
    let best = null;
    let bestScore = -1;
    for (const query of queries) {
      let list;
      try {
        list = librarySearch(library, query);
      } catch (error) {
        continue;
      }
      for (const item of list) {
        const key = stringOf(item.vod_id) + "|" + stringOf(item.vod_name);
        if (seen[key]) {
          continue;
        }
        seen[key] = true;
        const group = pickGroup(item);
        if (!group) {
          continue;
        }
        const name = normalizeTitle(item.vod_name);
        const base = similarity(name, wanted);
        if (base === 0) {
          continue;
        }
        // 单条「全集」也能用（会做时间切片），多集更好
        const score = base + Math.min(group.entries.length, 50);
        if (score > bestScore) {
          best = { library: library, item: item, group: group, score: score };
          bestScore = score;
        }
      }
      if (best && bestScore >= 100) {
        return best;
      }
    }
    if (best) {
      return best;
    }
  }
  return null;
}

function absoluteOf(base, address) {
  if (/^https?:\/\//i.test(address)) {
    return address;
  }
  try {
    return host.resolveUrl(base, address);
  } catch (error) {
    return address;
  }
}

function parseSegments(playlist) {
  const lines = playlist.split(/\r?\n/);
  const segments = [];
  const extras = [];
  let duration = 0;
  let pending = null;
  for (const raw of lines) {
    const line = raw.trim();
    if (line === "") {
      continue;
    }
    if (line.indexOf("#EXTINF:") === 0) {
      const value = parseFloat(line.slice(8).split(",")[0]);
      pending = isNaN(value) || value < 0 ? 0 : value;
      continue;
    }
    if (line.charAt(0) === "#") {
      if (
        line.indexOf("#EXT-X-MAP:") === 0 ||
        line.indexOf("#EXT-X-KEY:") === 0 ||
        line.indexOf("#EXT-X-BYTERANGE:") === 0
      ) {
        extras.push(line);
      }
      continue;
    }
    if (pending === null) {
      continue;
    }
    segments.push({ start: duration, duration: pending, address: line });
    duration += pending;
    pending = null;
    if (segments.length > maxSegmentScan) {
      break;
    }
  }
  return { segments: segments, extras: extras, duration: duration };
}

function pickMasterVariant(playlist, base) {
  const lines = playlist.split(/\r?\n/);
  let best = null;
  let bestBandwidth = -1;
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index].trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) {
      continue;
    }
    const match = /BANDWIDTH=([0-9]+)/.exec(line);
    const bandwidth = match ? intOf(match[1], 0) : 0;
    let next = "";
    for (let cursor = index + 1; cursor < lines.length; cursor++) {
      const candidate = lines[cursor].trim();
      if (candidate === "" || candidate.charAt(0) === "#") {
        continue;
      }
      next = candidate;
      break;
    }
    if (next === "") {
      continue;
    }
    if (bandwidth > bestBandwidth) {
      bestBandwidth = bandwidth;
      best = next;
    }
  }
  if (!best) {
    return "";
  }
  return host.resolveUrl(base, best);
}

function loadPlaylist(address, referer) {
  let result = host.fetchPlaylist({ url: address, referer: referer });
  let playlist = result.playlist || "";
  let base = result.url || address;
  if (playlist.indexOf("#EXT-X-STREAM-INF:") >= 0) {
    const variant = pickMasterVariant(playlist, base);
    if (variant === "") {
      throw new Error("片源没有可用的清晰度");
    }
    result = host.fetchPlaylist({ url: variant, referer: referer });
    playlist = result.playlist || "";
    base = result.url || variant;
  }
  if (playlist.indexOf("#EXTINF:") < 0) {
    throw new Error("片源播放列表为空");
  }
  return { playlist: playlist, base: base, durationMs: intOf(result.durationMs, 0) };
}

function directoryOf(address) {
  const cut = address.indexOf("?");
  const clean = cut >= 0 ? address.slice(0, cut) : address;
  const slash = clean.lastIndexOf("/");
  if (slash <= 8) {
    return clean;
  }
  return clean.slice(0, slash + 1);
}

function slicePlaylist(loaded, index, total) {
  const parsed = parseSegments(loaded.playlist);
  if (!parsed.segments.length) {
    throw new Error("片源播放列表无法解析");
  }
  const span = total > 1 ? parsed.duration / total : parsed.duration;
  let from = span * (index - 1);
  let to = span * index;
  if (index <= 1) {
    from = 0;
  }
  if (total > 1 && index >= total) {
    to = parsed.duration;
  }
  const chosen = parsed.segments.filter((segment) => segment.start + segment.duration > from + 0.0001 && segment.start < to - 0.0001);
  if (!chosen.length) {
    throw new Error("这一集没有对应的片源片段");
  }
  let target = 0;
  let total2 = 0;
  for (const segment of chosen) {
    total2 += segment.duration;
    target = Math.max(target, Math.ceil(segment.duration));
  }
  const lines = [
    "#EXTM3U",
    "#EXT-X-VERSION:3",
    "#EXT-X-TARGETDURATION:" + Math.max(target, 1),
    "#EXT-X-MEDIA-SEQUENCE:0",
    "#EXT-X-PLAYLIST-TYPE:VOD",
  ];
  const seen = {};
  for (const extra of parsed.extras) {
    if (seen[extra]) {
      continue;
    }
    seen[extra] = true;
    lines.push(extra);
  }
  for (const segment of chosen) {
    lines.push("#EXTINF:" + segment.duration.toFixed(6) + ",");
    lines.push(absoluteOf(loaded.base, segment.address));
  }
  lines.push("#EXT-X-ENDLIST");
  return { playlist: lines.join("\n") + "\n", durationMs: Math.round(total2 * 1000) };
}

function directEpisode(entry) {
  return { url: entry.address, referer: "", mode: "direct" };
}

function resolveFromLibrary(match, index, total) {
  const group = match.group;
  const entries = group.entries;
  const referer = match.library.base;
  if (entries.length > 1 && total > 1) {
    if (index < 1 || index > entries.length) {
      throw new Error("这一集超出了片源的分集范围");
    }
    const entry = entries[index - 1];
    if (entry.address.indexOf(".m3u8") < 0) {
      throw new Error("片源返回的不是直链播放地址");
    }
    const media = { url: entry.address, referer: referer };
    return host.prepareWebMedia(media, SOURCE_NAME);
  }
  const entry = entries[0];
  if (entry.address.indexOf(".m3u8") < 0) {
    throw new Error("片源返回的不是直链播放地址");
  }
  // 片源自报的集数优先（红果与片源集数可能差一两集），否则用红果的
  const declared = remarkCount(match.item);
  const sliceTotal = declared > 0 ? declared : Math.max(total, 1);
  const sliceIndex = Math.min(Math.max(index, 1), sliceTotal);
  const loaded = loadPlaylist(entry.address, referer);
  const sliced = slicePlaylist(loaded, sliceIndex, sliceTotal);
  return host.finishMedia({
    url: directoryOf(loaded.base),
    playlist: sliced.playlist,
    referer: referer,
    durationMs: sliced.durationMs,
  });
}

function resolveVideo(task) {
  const prefix = host.source + ":";
  const dramaId = task.dramaId.indexOf(prefix) === 0 ? task.dramaId.slice(prefix.length) : "";
  if (!/^[0-9]{1,32}$/.test(dramaId)) {
    throw new Error("剧集信息无效，请刷新详情");
  }
  const index = intOf(task.index, 0) || intOf(nested(task.chapter, "currentEpisode"), 1) || 1;
  const total = episodeCount(dramaId);
  const title = firstNonEmpty(task.dramaTitle, nested(task.drama, "title"));
  const match = matchLibrary(title);
  if (!match) {
    throw new Error("片源站没有找到《" + title + "》，换个剧源或稍后再试");
  }
  const media = resolveFromLibrary(match, index, total);
  if (media && media.url) {
    return media;
  }
  throw new Error("片源站没有返回可播放的地址");
}

module.exports = {
  validCategory(category) {
    if (category === "" || category === undefined || category === null) {
      return true;
    }
    return genres.some((genre) => genre.key === category);
  },

  categories() {
    return genres.map((genre) => ({ id: genre.key, name: genre.name }));
  },

  catalogPage(page, category) {
    const slug = genres.some((genre) => genre.key === category) ? category : genres[0].key;
    const number = intOf(page, 1) || 1;
    const path = "/category/" + slug + (number > 1 ? "?page=" + number : "");
    const data = webPage(path);
    const route = routerLoaderMap(data, "category_$", "category_");
    const rows = anyList(nested(route, "recommendList"));
    const items = [];
    for (const row of rows) {
      const entry = dramaFromRow(row);
      if (entry) {
        rememberCount(entry.sourceId, intOf(row.episode_cnt, 0));
        items.push(entry);
      }
    }
    const pagination = nested(route, "pagination") || {};
    const totalPages = intOf(pagination.totalPages, number);
    return { items: items, hasMore: items.length > 0 && number < totalPages };
  },

  search(page, query) {
    const keyword = stringOf(query);
    const number = intOf(page, 1) || 1;
    if (keyword === "" || number > 1) {
      return { items: [], hasMore: false };
    }
    const address =
      suggestionUrl +
      "?app_id=" + suggestionAppId +
      "&query=" + encodeURIComponent(keyword) +
      "&count=20";
    const data = parseJson(host.fetchText({ url: address, referer: siteBaseUrl + "/" }).body);
    const items = [];
    const seen = {};
    for (const row of anyList(data.suggest_list)) {
      const entry = dramaFromRow(row);
      if (!entry || seen[entry.sourceId]) {
        continue;
      }
      seen[entry.sourceId] = true;
      rememberCount(entry.sourceId, intOf(nested(row, "video_data", "episode_cnt"), 0));
      items.push(entry);
    }
    return { items: items, hasMore: false };
  },

  suggestions(query) {
    const keyword = stringOf(query);
    if (keyword === "") {
      return [];
    }
    const address =
      suggestionUrl +
      "?app_id=" + suggestionAppId +
      "&query=" + encodeURIComponent(keyword) +
      "&count=10";
    try {
      const data = parseJson(host.fetchText({ url: address, referer: siteBaseUrl + "/" }).body);
      const words = [];
      for (const row of anyList(data.suggest_list)) {
        const name = firstNonEmpty(nested(row, "video_data", "series_title"), row.name);
        if (name !== "" && words.indexOf(name) < 0) {
          words.push(name);
        }
      }
      return words;
    } catch (error) {
      return [];
    }
  },

  detail(sourceId) {
    const data = webPage("/detail?series_id=" + encodeURIComponent(sourceId));
    const page = routerLoaderMap(data, "detail_page", "detail_");
    const detail = nested(page, "seriesDetail");
    if (!isRecord(detail)) {
      throw new Error("红果没有返回这部剧的详情");
    }
    const entry = dramaFromRow(detail) || {
      id: host.dramaId(sourceId),
      source: host.source,
      sourceId: sourceId,
      title: sourceId,
      name: sourceId,
    };
    const chapters = [];
    const list = anyList(detail.vid_list);
    for (let index = 0; index < list.length; index++) {
      chapters.push({
        id: host.chapterId(sourceId, String(index + 1)),
        source: host.source,
        title: "第" + (index + 1) + "集",
        currentEpisode: index + 1,
      });
    }
    if (!chapters.length) {
      throw new Error("这部剧没有可播放的分集");
    }
    entry.totalEpisode = chapters.length;
    entry.episodeCount = chapters.length;
    rememberCount(sourceId, chapters.length);
    try {
      host.saveState("count-" + sourceId, String(chapters.length));
    } catch (error) {}
    return { drama: entry, chapters: chapters };
  },

  resolveMedia(task) {
    return resolveVideo(task);
  },
};
